"""
quality_checker.py — Output validation for GTA6 AI Content Factory
Every rendered clip is checked before being accepted for review or upload.
"""
import json
import subprocess
import shutil
from pathlib import Path
from typing import Dict, Optional


# ---------------------------------------------------------------------------
# ffprobe helpers
# ---------------------------------------------------------------------------

def _ffprobe(path: Path) -> Optional[Dict]:
    """Return ffprobe JSON output for a video file, or None on failure."""
    ffprobe = shutil.which("ffprobe") or "ffprobe"
    try:
        result = subprocess.run(
            [
                ffprobe, "-v", "quiet",
                "-print_format", "json",
                "-show_streams",
                "-show_format",
                str(path),
            ],
            capture_output=True, text=True, timeout=30,
        )
        if result.returncode == 0:
            return json.loads(result.stdout)
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def check_video(path: Path, min_duration: float = 20.0, max_duration: float = 65.0) -> Dict:
    """
    Validate a rendered clip.

    Returns a dict:
      {
        "ok": bool,
        "path": str,
        "issues": [str, ...],
        "width": int,
        "height": int,
        "duration": float,
        "has_audio": bool,
      }
    """
    result = {
        "ok":        False,
        "path":      str(path),
        "issues":    [],
        "width":     0,
        "height":    0,
        "duration":  0.0,
        "has_audio": False,
    }

    # --- Basic file checks ---
    if not path.exists():
        result["issues"].append("File does not exist")
        return result

    if not path.is_file():
        result["issues"].append("Path is not a file")
        return result

    size = path.stat().st_size
    if size < 50_000:
        result["issues"].append(f"File too small ({size} bytes) — likely corrupt or empty")
        return result

    # --- ffprobe analysis ---
    probe = _ffprobe(path)
    if not probe:
        result["issues"].append("ffprobe failed — file may be unreadable or corrupt")
        return result

    streams = probe.get("streams", [])

    video_stream = next((s for s in streams if s.get("codec_type") == "video"), None)
    audio_stream = next((s for s in streams if s.get("codec_type") == "audio"), None)

    if not video_stream:
        result["issues"].append("No video stream found")
        return result

    # --- Resolution ---
    width  = int(video_stream.get("width",  0))
    height = int(video_stream.get("height", 0))
    result["width"]  = width
    result["height"] = height

    if width != 1080 or height != 1920:
        result["issues"].append(f"Wrong resolution: {width}x{height} (expected 1080x1920)")

    # --- Aspect ratio ---
    if width > 0 and height > 0:
        ratio = height / width
        if abs(ratio - (16 / 9)) > 0.05:
            result["issues"].append(
                f"Aspect ratio {width}:{height} = {ratio:.3f} (expected ~1.778 for 9:16)"
            )

    # --- Duration ---
    fmt_duration = float(probe.get("format", {}).get("duration", 0) or 0)
    result["duration"] = round(fmt_duration, 2)

    if fmt_duration < min_duration:
        result["issues"].append(
            f"Duration too short: {fmt_duration:.1f}s (min {min_duration}s)"
        )
    if fmt_duration > max_duration:
        result["issues"].append(
            f"Duration too long: {fmt_duration:.1f}s (max {max_duration}s)"
        )

    # --- Audio ---
    result["has_audio"] = audio_stream is not None
    # We don't reject for missing audio (some clips might be silent gaming footage)
    # but we flag it
    if not audio_stream:
        result["issues"].append("No audio stream — verify this is intentional")

    # --- Determine overall pass/fail ---
    # Only hard-fail on critical issues (resolution, duration, corrupt)
    critical_keywords = [
        "File does not exist",
        "File too small",
        "ffprobe failed",
        "No video stream",
        "Wrong resolution",
        "Duration too short",
        "Duration too long",
    ]
    hard_fails = [
        issue for issue in result["issues"]
        if any(kw in issue for kw in critical_keywords)
    ]
    result["ok"] = len(hard_fails) == 0

    return result


def check_clips(paths: list, min_duration: float = 20.0, max_duration: float = 65.0) -> Dict:
    """
    Validate a list of clip paths.

    Returns:
      {
        "passed": [check_result, ...],
        "failed": [check_result, ...],
        "total":  int,
      }
    """
    passed = []
    failed = []

    for p in paths:
        r = check_video(Path(p), min_duration, max_duration)
        if r["ok"]:
            passed.append(r)
            print(f"[QC] ✓ PASS  {Path(p).name}  ({r['width']}x{r['height']}, {r['duration']:.1f}s)")
        else:
            failed.append(r)
            print(f"[QC] ✗ FAIL  {Path(p).name}")
            for issue in r["issues"]:
                print(f"         ↳ {issue}")

    return {"passed": passed, "failed": failed, "total": len(paths)}


# ---------------------------------------------------------------------------
# CLI self-test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    targets = sys.argv[1:] if len(sys.argv) > 1 else list(Path("output_clips").glob("*.mp4"))
    if not targets:
        print("Usage: python quality_checker.py [video.mp4 ...]")
    else:
        summary = check_clips([str(t) for t in targets])
        print(f"\n=== QC SUMMARY: {len(summary['passed'])}/{summary['total']} passed ===")
