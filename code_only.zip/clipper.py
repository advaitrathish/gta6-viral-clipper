"""
clipper.py — Video download, rendering, and editing for GTA6 AI Content Factory
Renders 1080x1920 (9:16) vertical Shorts with:
  - 50/50 split-screen (facecam detected) or blurred fallback
  - Four editing presets: comedy, action, cinematic, discovery
  - ASS caption burning
  - Audio loudness normalization
  - Hook text overlay via textfile (safe for all Unicode/special chars)
"""
import re
import shutil
import subprocess
import tempfile
import urllib.request
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2

from config import (
    COOKIES_FILE, WORK_DIR, OUTPUT_DIR, FONT_PATH,
    AUDIO_LOUDNESS_TARGET, AUDIO_TRUE_PEAK_TARGET,
)
from extractor import get_yt_dlp_base, seconds_to_hms
from caption_engine import generate_ass_captions

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

YUNET_URL  = "https://github.com/opencv/opencv_zoo/raw/main/models/face_detection_yunet/face_detection_yunet_2023mar.onnx"
YUNET_PATH = WORK_DIR / "face_detection_yunet_2023mar.onnx"

# Editing preset → FFmpeg style parameters
PRESET_STYLES = {
    "comedy": {
        "crf": "21",
        "preset": "fast",
        "saturation": 1.1,
        "contrast": 1.05,
    },
    "action": {
        "crf": "20",
        "preset": "fast",
        "saturation": 1.2,
        "contrast": 1.1,
    },
    "cinematic": {
        "crf": "18",
        "preset": "slow",
        "saturation": 0.95,
        "contrast": 1.0,
    },
    "discovery": {
        "crf": "21",
        "preset": "fast",
        "saturation": 1.05,
        "contrast": 1.05,
    },
    "default": {
        "crf": "22",
        "preset": "veryfast",
        "saturation": 1.0,
        "contrast": 1.0,
    },
}

# Map analyzer category → editing preset
CATEGORY_TO_PRESET = {
    "comedy":     "comedy",
    "fail":       "comedy",
    "unexpected": "comedy",
    "action":     "action",
    "cinematic":  "cinematic",
    "discovery":  "discovery",
    "story":      "discovery",
}


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------

def get_ffmpeg_exe() -> str:
    ff = shutil.which("ffmpeg")
    if ff:
        return ff
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        pass
    return "ffmpeg"


def sanitize_filename(name: str) -> str:
    cleaned = re.sub(r'[\\/*?:"<>|]+', "", name).strip()
    return cleaned[:55] or "viral_clip"


def _write_text_file(text: str, tmp_dir: Path) -> Path:
    """Write hook text to a temp UTF-8 file for FFmpeg textfile= filter."""
    p = tmp_dir / "hook_text.txt"
    p.write_text(text.upper(), encoding="utf-8")
    return p


def _probe_duration(video_path: Path) -> float:
    """Return video duration in seconds using ffprobe."""
    ff_probe = shutil.which("ffprobe") or "ffprobe"
    try:
        result = subprocess.run(
            [
                ff_probe, "-v", "error",
                "-show_entries", "format=duration",
                "-of", "default=noprint_wrappers=1:nokey=1",
                str(video_path),
            ],
            capture_output=True, text=True, timeout=15
        )
        return float(result.stdout.strip())
    except Exception:
        return 0.0


# ---------------------------------------------------------------------------
# YuNet face detection
# ---------------------------------------------------------------------------

def get_yunet_detector(w: int, h: int):
    if not YUNET_PATH.exists():
        print("[Clipper] Downloading YuNet face detection model...")
        urllib.request.urlretrieve(YUNET_URL, YUNET_PATH)
    return cv2.FaceDetectorYN.create(str(YUNET_PATH), "", (w, h), 0.75, 0.3, 5000)


def detect_facecam_corner(video_path: Path) -> Optional[str]:
    """
    Sample 5 frames and test all 4 corners for a streamer facecam.
    Returns the corner name if detected with ≥2/5 frame confidence, else None.
    """
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        return None

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    width        = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height       = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    if total_frames <= 0 or width <= 0 or height <= 0:
        cap.release()
        return None

    cw, ch   = int(width * 0.35), int(height * 0.42)
    detector = get_yunet_detector(cw, ch)
    corners  = {
        "top-left":     (0,          0,           cw,     ch),
        "top-right":    (width - cw, 0,           width,  ch),
        "bottom-left":  (0,          height - ch, cw,     height),
        "bottom-right": (width - cw, height - ch, width,  height),
    }
    scores = {k: 0 for k in corners}

    for p in (0.15, 0.35, 0.55, 0.75, 0.90):
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(total_frames * p))
        ok, frame = cap.read()
        if not ok:
            continue
        for name, (x1, y1, x2, y2) in corners.items():
            roi = frame[y1:y2, x1:x2]
            _, faces = detector.detect(roi)
            if faces is not None and len(faces) > 0:
                scores[name] += 1

    cap.release()
    best_corner, best_hits = max(scores.items(), key=lambda x: x[1])
    return best_corner if best_hits >= 2 else None


# ---------------------------------------------------------------------------
# Download
# ---------------------------------------------------------------------------

def download_clip_slice(url: str, start_hms: str, end_hms: str, raw_path: Path) -> bool:
    """Download only the [start_hms, end_hms] slice from a YouTube URL."""
    raw_path.unlink(missing_ok=True)
    section_arg = f"*{start_hms}-{end_hms}"
    ff_exe  = get_ffmpeg_exe()
    ff_args = ["--ffmpeg-location", ff_exe] if ff_exe != "ffmpeg" else []

    cmd = get_yt_dlp_base() + ff_args + [
        "--download-sections", section_arg,
        "--force-keyframes-at-cuts",
        "-f", "bestvideo[height<=1080][ext=mp4]+bestaudio[ext=m4a]/best[height<=1080][ext=mp4]/best",
        "--merge-output-format", "mp4",
        "-o", str(raw_path),
        url,
    ]
    print(f"[Clipper] Downloading slice {start_hms} → {end_hms}...")
    res = subprocess.run(cmd, check=False)
    ok  = res.returncode == 0 and raw_path.exists() and raw_path.stat().st_size > 10_000
    if not ok:
        print(f"[Clipper] ⚠ Download failed for slice {start_hms} → {end_hms}")
    return ok


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------

def _build_eq_filter(sat: float, contrast: float) -> str:
    """Build an eq= filter string for colour grading."""
    return f"eq=saturation={sat:.2f}:contrast={contrast:.2f}"


def render_vertical_short(
    raw_path: Path,
    out_path: Path,
    hook_text: str,
    corner: Optional[str],
    cues: List[Dict],
    clip_start_sec: float,
    clip_end_sec: float,
    preset: str = "default",
) -> bool:
    """
    Render a 1080x1920 vertical Short with:
    - Facecam split-screen (top 960px cam / bottom 960px gameplay) if corner detected
    - Blurred background + centered gameplay if no facecam
    - ASS caption burn-in
    - Hook text overlay using textfile (safe for special chars)
    - Audio loudness normalization
    - Preset-driven colour grading
    """
    ff_exe  = get_ffmpeg_exe()
    style   = PRESET_STYLES.get(preset, PRESET_STYLES["default"])
    eq_filt = _build_eq_filter(style["saturation"], style["contrast"])

    with tempfile.TemporaryDirectory(prefix="gta6_") as tmp_dir:
        tmp_path = Path(tmp_dir)

        # --- Generate ASS caption file ---
        ass_path  = tmp_path / "captions.ass"
        from config import FONT_PATH as CFG_FONT
        font_name = Path(CFG_FONT).stem if Path(CFG_FONT).exists() else "Arial"
        has_caps  = generate_ass_captions(
            cues, ass_path, clip_start_sec, clip_end_sec, font_name, 68, preset
        )

        # --- Write hook text file (safe for Unicode / apostrophes) ---
        hook_file = _write_text_file(hook_text, tmp_path)

        # --- Decide hook Y position ---
        hook_y = "915" if corner else "240"

        # --- Font path for drawtext ---
        font_path_safe = str(FONT_PATH).replace("\\", "/").replace(":", "\\:")

        # --- Build drawtext filter using textfile ---
        drawtext = (
            f"drawtext=textfile='{hook_file.as_posix()}':"
            f"fontfile='{font_path_safe}':"
            f"fontcolor=white:fontsize=58:"
            f"box=1:boxcolor=black@0.80:boxborderw=16:"
            f"x=(w-text_w)/2:y={hook_y}:"
            f"fix_bounds=1"
        )

        # --- ASS filter ---
        ass_filter = f"ass='{ass_path.as_posix()}'" if has_caps else ""

        # --- Build filter_complex ---
        if corner:
            cam_crop_map = {
                "top-left":     "crop=iw*0.34:ih*0.48:0:0",
                "top-right":    "crop=iw*0.34:ih*0.48:iw*0.66:0",
                "bottom-left":  "crop=iw*0.34:ih*0.48:0:ih*0.52",
                "bottom-right": "crop=iw*0.34:ih*0.48:iw*0.66:ih*0.52",
            }
            cam_crop = cam_crop_map[corner]

            # Overlay chain: cam top, game bottom, then caption, then hook
            after_vstack = "[stacked]"
            filter_parts = [
                f"[0:v]{cam_crop},{eq_filt},scale=1080:960:force_original_aspect_ratio=increase,"
                f"crop=1080:960,setsar=1[cam]",
                f"[0:v]crop=ih*9/8:ih:(iw-ih*9/8)/2:0,{eq_filt},scale=1080:960,setsar=1[game]",
                f"[cam][game]vstack=inputs=2{after_vstack}",
            ]
            last_label = "stacked"
        else:
            filter_parts = [
                f"[0:v]scale=1080:1920:force_original_aspect_ratio=increase,"
                f"crop=1080:1920,boxblur=25:10,{eq_filt},eq=brightness=-0.12[bg]",
                f"[0:v]{eq_filt},scale=1080:-2[fg]",
                f"[bg][fg]overlay=(W-w)/2:(H-h)/2[comp]",
            ]
            last_label = "comp"

        # Apply ASS captions if available
        if ass_filter:
            filter_parts.append(f"[{last_label}]{ass_filter}[captioned]")
            last_label = "captioned"

        # Apply hook drawtext
        filter_parts.append(f"[{last_label}]{drawtext}[outv]")

        filter_complex = ";\n".join(filter_parts)

        # --- Audio normalization using loudnorm ---
        audio_filter = (
            f"loudnorm=I={AUDIO_LOUDNESS_TARGET}:"
            f"TP={AUDIO_TRUE_PEAK_TARGET}:LRA=11"
        )

        # --- Full FFmpeg command ---
        cmd = [
            ff_exe, "-y",
            "-i", str(raw_path),
            "-filter_complex", filter_complex,
            "-map", "[outv]",
            "-map", "0:a?",
            "-af", audio_filter,
            "-c:v", "libx264",
            "-preset", style["preset"],
            "-crf", style["crf"],
            "-c:a", "aac",
            "-b:a", "192k",
            "-ar", "48000",
            "-movflags", "+faststart",
            "-pix_fmt", "yuv420p",
            str(out_path),
        ]

        print(f"[Clipper] Rendering {preset.upper()} preset → {out_path.name}...")
        res = subprocess.run(cmd, check=False)

        if res.returncode != 0 or not out_path.exists():
            # Fallback: try without ASS captions (sometimes ffmpeg chokes on font paths)
            print("[Clipper] ⚠ Primary render failed. Retrying without captions...")
            if corner:
                filter_simple = (
                    f"[0:v]{cam_crop_map[corner]},{eq_filt},scale=1080:960:force_original_aspect_ratio=increase,"
                    f"crop=1080:960,setsar=1[cam];"
                    f"[0:v]crop=ih*9/8:ih:(iw-ih*9/8)/2:0,{eq_filt},scale=1080:960,setsar=1[game];"
                    f"[cam][game]vstack=inputs=2[outv]"
                )
            else:
                filter_simple = (
                    f"[0:v]scale=1080:1920:force_original_aspect_ratio=increase,"
                    f"crop=1080:1920,boxblur=25:10,eq=brightness=-0.12[bg];"
                    f"[0:v]scale=1080:-2[fg];"
                    f"[bg][fg]overlay=(W-w)/2:(H-h)/2[outv]"
                )
            cmd_fallback = [
                ff_exe, "-y",
                "-i", str(raw_path),
                "-filter_complex", filter_simple,
                "-map", "[outv]",
                "-map", "0:a?",
                "-af", audio_filter,
                "-c:v", "libx264",
                "-preset", "veryfast",
                "-crf", "22",
                "-c:a", "aac",
                "-b:a", "128k",
                "-movflags", "+faststart",
                "-pix_fmt", "yuv420p",
                str(out_path),
            ]
            res = subprocess.run(cmd_fallback, check=False)

        return res.returncode == 0 and out_path.exists() and out_path.stat().st_size > 10_000


# ---------------------------------------------------------------------------
# Main build orchestrator
# ---------------------------------------------------------------------------

def build_clips(
    url: str,
    clips: List[Dict],
    cues: List[Dict],
    top_n: int = 3,
) -> List[Dict]:
    """
    Download and render the top_n clips from the analyzer output.

    Args:
        url:   Source YouTube URL
        clips: List of clip dicts from analyzer.find_viral_clips()
        cues:  List of subtitle cues from extractor (for caption burn-in)
        top_n: Maximum number of clips to build

    Returns:
        List of dicts describing each built clip (path, metadata, success)
    """
    ranked    = sorted(clips, key=lambda c: c.get("virality_score", 0), reverse=True)[:top_n]
    generated = []

    for idx, clip in enumerate(ranked, 1):
        raw_file   = WORK_DIR / f"raw_slice_{idx}.mp4"
        safe_title = sanitize_filename(clip["title"])
        category   = clip.get("category", "default").lower()
        preset     = CATEGORY_TO_PRESET.get(category, "default")
        final_file = OUTPUT_DIR / f"clip_{idx:02d}_{preset}_{safe_title}.mp4"

        start_hms = clip.get("start_hms") or seconds_to_hms(clip["start_sec"])
        end_hms   = clip.get("end_hms")   or seconds_to_hms(clip["end_sec"])

        # Download
        if not download_clip_slice(url, start_hms, end_hms, raw_file):
            print(f"[Clipper] ✗ Clip #{idx} download failed — skipping.")
            generated.append({"index": idx, "success": False, "clip": clip})
            continue

        # Detect facecam
        corner       = detect_facecam_corner(raw_file)
        layout_label = f"50/50 Split (Facecam: {corner})" if corner else "Blurred 9:16 Fallback"
        print(f"[Clipper] Layout → {layout_label} | Preset → {preset.upper()}")

        # Render
        success = render_vertical_short(
            raw_path       = raw_file,
            out_path       = final_file,
            hook_text      = clip.get("hook_overlay", clip["title"]),
            corner         = corner,
            cues           = cues,
            clip_start_sec = clip["start_sec"],
            clip_end_sec   = clip["end_sec"],
            preset         = preset,
        )

        if success:
            print(f"[Clipper] ✓ Saved → {final_file}")
            generated.append({
                "index":   idx,
                "success": True,
                "path":    str(final_file),
                "clip":    clip,
                "preset":  preset,
                "layout":  layout_label,
            })
        else:
            print(f"[Clipper] ✗ Render failed for clip #{idx}")
            generated.append({"index": idx, "success": False, "clip": clip})

        raw_file.unlink(missing_ok=True)

    return generated


# ---------------------------------------------------------------------------
# CLI self-test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    test_url   = "https://www.youtube.com/watch?v=qMafmHDMufw"
    sample_clip = [{
        "title":        "Speed Reacts To Iconic Lamar Roast Scene",
        "hook_overlay": "SPEED CAN'T HANDLE THIS",
        "start_hms":    "00:21:12",
        "end_hms":      "00:21:50",
        "start_sec":    1272.0,
        "end_sec":      1310.0,
        "virality_score": 98,
        "category":     "comedy",
    }]
    outputs = build_clips(test_url, sample_clip, cues=[], top_n=1)
    print("\n=== RENDER COMPLETE ===", outputs)