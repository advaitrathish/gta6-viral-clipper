"""
telegram_trigger.py — Optional Telegram bot for mobile control of GTA6 AI Content Factory

Commands:
  /start   — Welcome message and help
  /help    — List commands
  /run     — Start a new clip job (DM the URL after)
  /status  — Check current job status
  /clips   — List generated clips
  /approve — Mark a clip as approved for upload
  /reject  — Mark a clip as rejected

Setup:
  1. Create a bot with @BotFather on Telegram
  2. Add TELEGRAM_BOT_TOKEN and TELEGRAM_ALLOWED_USER to .env
  3. Run: python telegram_trigger.py

Requirements:
  pip install python-telegram-bot

Security: Only responds to TELEGRAM_ALLOWED_USER (your Telegram user ID).
"""
import json
import logging
import os
import sys
import threading
from pathlib import Path

try:
    from telegram import Update
    from telegram.ext import (
        Application, CommandHandler, MessageHandler,
        filters, ContextTypes
    )
    TELEGRAM_AVAILABLE = True
except ImportError:
    TELEGRAM_AVAILABLE = False

from config import TELEGRAM_BOT_TOKEN, TELEGRAM_ALLOWED_USER, OUTPUT_DIR

logger = logging.getLogger("telegram_trigger")

# ---------------------------------------------------------------------------
# Job state (in-memory, single process)
# ---------------------------------------------------------------------------
_job_state = {
    "running": False,
    "url":     None,
    "status":  "idle",
    "clips":   [],
}
_pending_url_from_user: dict = {}


# ---------------------------------------------------------------------------
# Auth guard
# ---------------------------------------------------------------------------

def _is_authorized(update: Update) -> bool:
    allowed = TELEGRAM_ALLOWED_USER.strip()
    if not allowed:
        logger.warning("TELEGRAM_ALLOWED_USER not set — denying all requests.")
        return False
    user_id = str(update.effective_user.id)
    return user_id == allowed


# ---------------------------------------------------------------------------
# Handlers
# ---------------------------------------------------------------------------

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_authorized(update):
        return
    await update.message.reply_text(
        "🎮 *GTA6 AI Content Factory* — Mobile Control\n\n"
        "Commands:\n"
        "/run — Send me a YouTube URL to process\n"
        "/status — Check current job\n"
        "/clips — List generated clips\n"
        "/approve N — Approve clip #N\n"
        "/reject N — Reject clip #N\n"
        "/help — Show this message",
        parse_mode="Markdown",
    )


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await cmd_start(update, context)


async def cmd_run(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_authorized(update):
        return
    if _job_state["running"]:
        await update.message.reply_text(
            f"⚠️ A job is already running for:\n{_job_state['url']}\n\nStatus: {_job_state['status']}"
        )
        return
    user_id = str(update.effective_user.id)
    _pending_url_from_user[user_id] = True
    await update.message.reply_text(
        "📎 Send me the YouTube URL to process.\n\n"
        "Example: https://www.youtube.com/watch?v=XXXX"
    )


async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_authorized(update):
        return
    if _job_state["running"]:
        await update.message.reply_text(
            f"⚙️ Processing: {_job_state['url']}\nStatus: {_job_state['status']}"
        )
    else:
        await update.message.reply_text(
            f"💤 No job running.\nLast status: {_job_state['status']}"
        )


async def cmd_clips(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_authorized(update):
        return
    clips = list(OUTPUT_DIR.glob("*.mp4"))
    if not clips:
        await update.message.reply_text("📂 No clips in output_clips/ yet.")
        return
    lines = [f"📹 Generated clips ({len(clips)} found):"]
    for i, c in enumerate(clips[:10], 1):
        size_mb = c.stat().st_size / 1_048_576
        lines.append(f"  #{i}: {c.name} ({size_mb:.1f} MB)")
    await update.message.reply_text("\n".join(lines))


async def cmd_approve(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_authorized(update):
        return
    clips = list(OUTPUT_DIR.glob("*.mp4"))
    args  = context.args
    if args and args[0].isdigit():
        idx = int(args[0]) - 1
        if 0 <= idx < len(clips):
            clip = clips[idx]
            # Write approval marker
            (clip.parent / (clip.stem + ".approved")).touch()
            await update.message.reply_text(f"✅ Approved: {clip.name}")
            return
    await update.message.reply_text("Usage: /approve N (use /clips to see numbers)")


async def cmd_reject(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_authorized(update):
        return
    clips = list(OUTPUT_DIR.glob("*.mp4"))
    args  = context.args
    if args and args[0].isdigit():
        idx = int(args[0]) - 1
        if 0 <= idx < len(clips):
            clip = clips[idx]
            (clip.parent / (clip.stem + ".rejected")).touch()
            await update.message.reply_text(f"❌ Rejected: {clip.name}")
            return
    await update.message.reply_text("Usage: /reject N (use /clips to see numbers)")


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_authorized(update):
        return

    user_id = str(update.effective_user.id)
    text    = (update.message.text or "").strip()

    if _pending_url_from_user.pop(user_id, False):
        # User just sent a URL after /run
        if not text.startswith("http"):
            await update.message.reply_text("❌ That doesn't look like a URL. Use /run to try again.")
            return

        url = text
        await update.message.reply_text(
            f"🚀 Starting pipeline for:\n{url}\n\nThis runs locally on your PC."
        )

        def _run_pipeline():
            _job_state["running"] = True
            _job_state["url"]     = url
            _job_state["status"]  = "extracting signals..."
            try:
                from pipeline import run_pipeline
                result = run_pipeline(url=url, max_clips=5, top_n=3)
                _job_state["status"] = "done"
                _job_state["clips"]  = [
                    r.get("path") for r in result.get("results", [])
                    if r.get("success")
                ]
                # Notify user (best effort — requires bot still running)
                n = result.get("clips_built", 0)
                # Can't use await here (non-async thread) — just update state
                logger.info(f"Telegram pipeline done: {n} clips built")
            except Exception as e:
                _job_state["status"] = f"error: {e}"
                logger.error(f"Pipeline error: {e}")
            finally:
                _job_state["running"] = False

        threading.Thread(target=_run_pipeline, daemon=True).start()
        await update.message.reply_text(
            "⚙️ Pipeline started! Use /status to check progress."
        )
    else:
        await update.message.reply_text(
            "Use /run to start a new job, or /help for commands."
        )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def run_bot():
    if not TELEGRAM_AVAILABLE:
        print("❌ python-telegram-bot not installed. Run: pip install python-telegram-bot")
        sys.exit(1)

    if not TELEGRAM_BOT_TOKEN:
        print("❌ TELEGRAM_BOT_TOKEN not set in .env")
        sys.exit(1)

    if not TELEGRAM_ALLOWED_USER:
        print("⚠️  TELEGRAM_ALLOWED_USER not set — bot will refuse all requests!")

    logging.basicConfig(level=logging.INFO)
    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()

    app.add_handler(CommandHandler("start",   cmd_start))
    app.add_handler(CommandHandler("help",    cmd_help))
    app.add_handler(CommandHandler("run",     cmd_run))
    app.add_handler(CommandHandler("status",  cmd_status))
    app.add_handler(CommandHandler("clips",   cmd_clips))
    app.add_handler(CommandHandler("approve", cmd_approve))
    app.add_handler(CommandHandler("reject",  cmd_reject))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    print(f"🤖 Telegram bot started. Authorized user: {TELEGRAM_ALLOWED_USER or '(none)'}")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    run_bot()
